#!/bin/bash
source ~/.bash_profile

dt=`/bin/date +%d%m%Y`

SCRIPT_DIR=/app/UDMF/WDC_RECON/recon_scripts/
CONF_DIR=/app/UDMF/WDC_RECON/recon_config/
JAR_DIR=/app/UDMF/WDC_RECON/recon_jars/
LOG_DIR=/app/UDMF/WDC_RECON/recon_logs/
SPARK_HOME=/app/UDMF/software/spark/
LOG_FILE=${LOG_DIR}WDCPierTicketIntegrationProcess.log_"$dt"_1

touch $LOG_FILE
chmod 777 $LOG_FILE
# Removal of 3 days old log files.
for FILE in `find $LOG_DIR -mtime +3 | grep "TRANSID_SPARK_SPOOLING\.log_"`
do
rm -f "$FILE" 2>/dev/null
done
# Check if the instance of the script is already running.
if [ -e ${LOG_DIR}WDCPierTicket.lck ]
then
echo "Another initiation Failed!!! Another Script is already running. New instance will not be invoked. !!" >> ${LOG_FILE}
(>&2 echo "Another initiation Failed!!! Another Script is already running. New instance will not be invoked. !!")
exit 1
fi
#------------------------------------------------------------------------------------------------------
echo $$
trap 'echo "Kill Signal Received.\n";exit' SIGHUP SIGINT SIGQUIT SIGTERM SIGSEGV


echo "Performing WDC PIER TICKET Integration Process" >> ${LOG_FILE}
touch ${LOG_DIR}WDCPierTicket.lck
chmod 777 ${LOG_DIR}WDCPierTicket.lck

###Connect to Share point Read Inputfile and place it in input/processig folder###

source /app/UDMF/WDC_RECON/recon_config/common_config.conf

Token_URL="https://accounts.accesscontrol.windows.net/be0f980b-dd99-4b19-bd7b-bc71a09b026c/tokens/OAuth/2"
resource='00000003-0000-0ff1-ce00-000000000000/tmobileusa.sharepoint.com@be0f980b-dd99-4b19-bd7b-bc71a09b026c'
resource_test="resource=$resource"
client_secret_test="client_secret=$clientsecret"

##ACCESS TOKEN GENERATION##
access_token=`curl --location --request POST $Token_URL \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'grant_type=client_credentials' \
--data-urlencode 'client_id=d0aa7607-4081-4f3a-a562-7adc2ebf45b7@be0f980b-dd99-4b19-bd7b-bc71a09b026c' \
--data-urlencode $client_secret_test \
--data-urlencode $resource_test`
access_token_actual=`echo "$access_token"|awk -F ',' '{print $6}'|awk -F ':' '{print $2}'|awk -F '"' '{print $2}'`
#echo "$access_token_actual"

############Retrive files from sharepoint Input Folder############

files=`curl -X  --retry 5 --retry-max-time 120 --location --request GET 'https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Input'\'')/files' \
--header "Authorization: Bearer $access_token_actual"   \
--header "Accept: application/json;odata=verbose" \
--header "Content-Type: text/csv"`
echo "$files"
for  i in `echo "$files" | grep -oP '"id": *"[^"]+"' | sed 's/"id": "//'| awk -F '"' '{print $4}'`
do
        echo "$i"
        filename=`echo "$i"|awk -F "/" '{print $NF}'|awk -F "'" '{print $1}'`
        echo "$filename"
        echo "\n #############################################################################\n"

        curl   -o "/app/UDMF/WDC_RECON/recon_pierticket/input/$filename" --retry 5 --retry-max-time 120 --location  "$i/\$value" \
        --header "Authorization: Bearer $access_token_actual"   \
        --header 'Accept: application/json;odata=verbose' \
        --header 'Content-Type: text/csv'

#Set the SharePoint REST API endpoint to move a file
        SITE_URL="https://tmobileusa.sharepoint.com/teams/Scow"
        source_path="/teams/Scow/DC77DenodoFiles/Production/PierTicket/Input/"
        SOURCE_FILE_PATH=$source_path$filename
        DESTINATION_FOLDER_PATH="/teams/Scow/DC77DenodoFiles/Production/PierTicket/Processing/"
        DESTINATION_FILE_PATH=$DESTINATION_FOLDER_PATH$filename
API_URL="$SITE_URL/_api/web/getfilebyserverrelativeurl('$SOURCE_FILE_PATH')/copyto(strnewurl='$DESTINATION_FILE_PATH',boverwrite=true)"

# Perform the cURL request to Copy the files Under SharePoint Input to processing Folder
        echo "\n after download ########################################################\n"
        curl -X POST "$API_URL" \
        --header "Authorization: Bearer $access_token_actual"   \
        --header 'Accept: application/json' \
        --header 'Content-Type: application/json' \
        -d "{ }"

######delete the file from input folder

        echo "\n deleteing the file from input folder*******************\n  "
        curl -X POST "$SITE_URL/_api/web/GetFileByServerRelativeUrl('$source_path{$filename}')" \
        -H "Authorization: Bearer $access_token_actual" \
        -H "If-Match: *" \
        -H "X-HTTP-Method: DELETE" \
        -H "X-RequestDigest: "{form_digest_value}"" \
        -H "Accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Content-Length: 0"

        echo "*******************************"
	sleep 30s
done

mv /app/UDMF/WDC_RECON/recon_pierticket/input/*.csv /app/UDMF/WDC_RECON/recon_pierticket/processing/

## Copy files from local system to hdfs processing folder###
/app/UDMF/software/hadoop/bin/hadoop dfs -copyFromLocal /app/UDMF/WDC_RECON/recon_pierticket/processing/*.csv /app/UDMF/WDC_RECON/recon_pierticket/processing/

#Starting the cassandra extraction spark job execution
${SPARK_HOME}bin/spark-submit \
--class com.tmobile.wdcRecon.WDCPierTicketIntegration \
--master yarn \
--deploy-mode cluster \
--queue CYCLIC \
--conf "spark.executor.extraJavaOptions=-XX:MaxPermSize=1024M" \
--conf spark.executor.memoryOverhead=1024m \
--conf spark.dynamicAllocation.enabled=false \
--conf spark.sql.autoBroadcastJoinThreshold=209715200 \
--conf spark.sql.shuffle.partitions=50 \
--conf spark.shuffle.blockTransferService=nio \
--driver-memory 2g \
--num-executors 8 \
--executor-memory 6g \
--executor-cores 8 \
${JAR_DIR}soa-wdc-reconciliation-service.jar  ${CONF_DIR}  common_config.conf

if [ $? -eq 0 ]
then
    echo "WDCPierTicketIntegration is completed successfully"
    rm -f ${LOG_DIR}WDCPierTicket.lck
    echo "Lock Released" >> ${LOG_FILE}
else
        echo "WDC WDCPierTicketIntegration extraction job has failed!!"  | mail -s "WDC WDCPierTicketIntegration extraction job has failed!!" scdigitalops-recon@T-Mobile.com
	rm -f ${LOG_DIR}WDCPierTicket.lck
        echo "Lock Released" >> ${LOG_FILE}
	rm -f /app/UDMF/WDC_RECON/recon_pierticket/processing/*
	/app/UDMF/software/hadoop/bin/hadoop dfs -rm /app/UDMF/WDC_RECON/recon_pierticket/processing/*
	exit 1
fi

######Pushing Processed DATA TO SHAREPOINT#########################
rm -rf /app/UDMF/WDC_RECON/recon_pierticket/processed/*.csv
filename_processed=`/app/UDMF/software/hadoop/bin/hadoop dfs -cat /app/UDMF/WDC_RECON/recon_config/pier_processed_file_name.conf `
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n"
echo "\033[5;37;41m $filename_processed  \033[0m\n"
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n"



WDCPierProcessedFolderpath=/app/UDMF/WDC_RECON/recon_pierticket/processed/
/app/UDMF/software/hadoop/bin/hadoop dfs -copyToLocal ${WDCPierProcessedFolderpath}*.csv ${WDCPierProcessedFolderpath}
ProcessedFileName=${WDCPierProcessedFolderpath}${filename_processed}

if [ -e ${ProcessedFileName} ]
then
        author="'Authorization: Bearer $access_token_actual '"
        filecontent="@"$ProcessedFileName
        #echo $filecontent
        #echo "$author"
        sharepoint_url='https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Processed/'\'')/Files/add(url='\'$filename_processed\'',overwrite=true)'
        echo "$sharepoint_url"
        curl -T $ProcessedFileName --retry 5 --retry-max-time 120 --location --request POST 'https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Processed'\'')/Files/Add(url='\'$filename_processed\'',overwrite=true)' \
                --header "Authorization: Bearer $access_token_actual"   \
                --header 'Accept: application/json;odata=verbose' \
                --header 'Content-Type: text/csv' \
                #--data $filecontent
                if [ $? -eq 0 ]
                then
                        echo "file uploaded sucessfully to sharepoint Processed folder"
                else
                        echo "getting error while uploading the file to sharepoint Processed folder"
                         echo "getting error while uploading the file $ProcessedFileName to sharepoint Processed  folder "  | mail -s "Unable to upload $filename_processed to sharepoint folder" mounica.arepalli1@t-mobile.com,venkatabhagyalakshmi.essireddy1@t-mobile.com,radhakrishna.bodapati6@t-mobile.com,scrumologists_digital@t-mobile.com
                

		echo "\033[5;37;41m We are at proccessed stage \033[0m"
		sleep 30s


	fi
fi


######Pushing Error DATA TO SHAREPOINT#########################
rm -r /app/UDMF/WDC_RECON/recon_pierticket/error/*
filename_error=`/app/UDMF/software/hadoop/bin/hadoop dfs -cat /app/UDMF/WDC_RECON/recon_config/pier_error_file_name.conf `
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n"
echo "$filename_error\n"
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n"


WDCPierErrorFolderpath=/app/UDMF/WDC_RECON/recon_pierticket/error/
/app/UDMF/software/hadoop/bin/hadoop dfs -copyToLocal ${WDCPierErrorFolderpath}*.csv ${WDCPierErrorFolderpath}
ErrorFileName=${WDCPierErrorFolderpath}${filename_error}
if [ -e ${ErrorFileName} ]
then
        author="'Authorization: Bearer $access_token_actual '"
        filecontent="@"$ErrorFileName
        #echo $filecontent
        #echo "$author"
        sharepoint_url='https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Errors/'\'')/Files/add(url='\'$filename_error\'',overwrite=true)'
        echo "$sharepoint_url"
        curl -T $ErrorFileName --retry 5 --retry-max-time 120 --location --request POST 'https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Errors'\'')/Files/Add(url='\'$filename_error\'',overwrite=true)' \
        --header "Authorization: Bearer $access_token_actual"   \
        --header 'Accept: application/json;odata=verbose' \
        --header 'Content-Type: text/csv' \
        #--data $filecontent


        if [ $? -eq 0 ]
        then
                echo "file uploaded sucessfully to sharepoint folder"
        else
                echo "getting error while uploading the file to sharepoint Errors folder"
                 echo "getting error while uploading the file $ErrorFileName to sharepoint Error folder "  | mail -s "Unable to upload $filename_error to sharepoint folder" mounica.arepalli1@t-mobile.com,venkatabhagyalakshmi.essireddy1@t-mobile.com,radhakrishna.bodapati6@t-mobile.com,scrumologists_digital@t-mobile.com
        fi
	echo " \033[5;37;41m We are at error stage \033[0m"
	sleep 30s
fi

processingfiles=`curl -X  --retry 5 --retry-max-time 120 --location --request GET 'https://tmobileusa.sharepoint.com/teams/Scow/_api/web/GetFolderByServerRelativeUrl('\''/teams/Scow/DC77DenodoFiles/Production/PierTicket/Processing'\'')/files' \
--header "Authorization: Bearer $access_token_actual"   \
--header 'Accept: application/json;odata=verbose' \
--header 'Content-Type: text/csv' `

for  i in `echo "$processingfiles" | grep -oP '"id": *"[^"]+"' | sed 's/"id": "//'| awk -F '"' '{print $4}'`
do
        echo "$i"
        filename=`echo "$i"|awk -F "/" '{print $NF}'|awk -F "'" '{print $1}'`
        echo "$filename"
        echo "\n #############################################################################\n"


#Set the SharePoint REST API endpoint of each file
        SITE_URL="https://tmobileusa.sharepoint.com/teams/Scow"
        source_path="/teams/Scow/DC77DenodoFiles/Production/PierTicket/Processing/"
        SOURCE_FILE_PATH=$source_path$filename
        DESTINATION_FOLDER_PATH="/teams/Scow/DC77DenodoFiles/Production/PierTicket/Archive/"
        DESTINATION_FILE_PATH=$DESTINATION_FOLDER_PATH$filename
API_URL="$SITE_URL/_api/web/getfilebyserverrelativeurl('$SOURCE_FILE_PATH')/copyto(strnewurl='$DESTINATION_FILE_PATH',boverwrite=true)"

echo "we are moving the files from SharePoint Processing to Archive"

# Perform the cURL request to Copy the files Under SharePoint Processing to Archive Folder
        echo "\n after download ########################################################\n"
        curl -X POST "$API_URL" \
        --header "Authorization: Bearer $access_token_actual"   \
        --header 'Accept: application/json' \
        --header 'Content-Type: application/json' \
        -d "{ }"

######delete the file from Sahrepoint Processingfolder

        echo "\n deleteing the file from Processing folder*******************\n  "
        curl -X POST "$SITE_URL/_api/web/GetFileByServerRelativeUrl('$source_path{$filename}')" \
        -H "Authorization: Bearer $access_token_actual" \
        -H "If-Match: *" \
        -H "X-HTTP-Method: DELETE" \
        -H "X-RequestDigest: "{form_digest_value}"" \
        -H "Accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Content-Length: 0"

        echo "*******************************"

done

#####Copying files to Archive
/app/UDMF/software/hadoop/bin/hadoop dfs -mv /app/UDMF/WDC_RECON/recon_pierticket/processing/*.csv /app/UDMF/WDC_RECON/recon_pierticket/archive
rm -r /app/UDMF/WDC_RECON/recon_pierticket/processing/*
