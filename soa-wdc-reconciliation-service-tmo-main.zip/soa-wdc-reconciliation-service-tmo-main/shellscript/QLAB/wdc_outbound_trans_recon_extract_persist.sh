#!/bin/bash
source ~/.bash_profile

dt=`/bin/date +%d%m%Y`

SCRIPT_DIR=/app/RECON/WDC_RECON/recon_scripts/
CONF_DIR=/app/RECON/WDC_RECON/recon_config/
JAR_DIR=/app/RECON/WDC_RECON/recon_jars/
LOG_DIR=/app/RECON/WDC_RECON/recon_logs/
SPARK_HOME=/app/UDMF/software/spark-3.1.1-bin-hadoop2.7/
LOG_FILE=${LOG_DIR}WDCOutboundTransExtract.log_"$dt"_1

touch $LOG_FILE
chmod 777 $LOG_FILE
# Removal of 3 days old log files.
for FILE in `find $LOG_DIR -mtime +3 | grep "TRANSID_SPARK_SPOOLING\.log_"`
do
rm -f "$FILE" 2>/dev/null
done
# Check if the instance of the script is already running.
if [ -e ${LOG_DIR}WDCOutboundTransExtract.lck ]
then
echo "Another initiation Failed!!! Another Script is already running. New instance will not be invoked. !!" >> ${LOG_FILE}
(>&2 echo "Another initiation Failed!!! Another Script is already running. New instance will not be invoked. !!")
exit 1
fi
#------------------------------------------------------------------------------------------------------
echo $$
trap 'echo "Kill Signal Received.\n";exit' SIGHUP SIGINT SIGQUIT SIGTERM SIGSEGV

#cat $FILE

echo "Extracting data for yesterday from SOA for TRANSID Report" >> ${LOG_FILE}
touch ${LOG_DIR}WDCOutboundTransExtract.lck
chmod 777 ${LOG_DIR}WDCOutboundTransExtract.lck

previoushourdate=$(date '+%Y-%m-%d %H:%M:%S' -d  "1 hour ago")
time_config_file=/app/RECON/WDC_RECON/recon_config/wdc_outbound_trans_extract_time.conf

sed -i "s/startTime=.*/startTime=\"$previoushourdate\"/" "$time_config_file"

/app/UDMF/software/hadoop/bin/hadoop dfs -rm $time_config_file
/app/UDMF/software/hadoop/bin/hadoop dfs -copyFromLocal $time_config_file $time_config_file


#Starting the cassandra extraction spark job execution
${SPARK_HOME}bin/spark-submit \
--class com.tmobile.wdcRecon.WDCOutboundTransExtract \
--master yarn \
--deploy-mode cluster \
--queue CYCLIC \
--conf "spark.executor.extraJavaOptions=-XX:MaxPermSize=1024M" \
--conf spark.executor.memoryOverhead=1024m \
--conf spark.dynamicAllocation.enabled=false \
--conf spark.shuffle.blockTransferService=nio \
--driver-java-options -XX:MaxPermSize=1024m \
--driver-memory 2g \
--num-executors 8 \
--executor-memory 6g \
--executor-cores 8 \
${JAR_DIR}soa-wdc-reconciliation-service.jar  ${CONF_DIR}  common_config.conf

if [ $? -eq 0 ]
then
    echo "WDC OutboundTransExtract extraction is completed successfully"
    #echo "Coping the data to monday date file"
    #nohup ${SCRIPT_DIR}wdc_write_data_to_mondayfile.sh >> ${LOG_DIR}wdc_write_data_to_mondayfile_$dt.log 2>&1 &
    rm -f ${LOG_DIR}WDCOutboundTransExtract.lck
    echo "Lock Released" >> ${LOG_FILE}
else
        echo "WDC OutboundTransExtract extraction job has failed!!" >> ${LOG_FILE}
        cd $LOG_DIR
        sparkfn=$(ls -rt1 sparkstacktrace.log|tail -1)
        for LOG_DIR in ${sparkfn}
        do
            sparkfile1=`echo $LOG_DIR|cut -d ' ' -f 1`
            ( printf "Dear All,"
                        printf '%s\n'
                        printf '%s\n'
                        printf '%s\n' "WDC OutboundTransExtract extraction job Failed."
                        printf '%s\n' "Please find the attached error stack log for analysis."
                        printf '%s\n'
                        printf '%s\n' "Thanks,"
                        printf '%s\n' "DIFR-UDMF-RECON Team" ) | mailx -s "WDC OutboundTransExtract extraction job failed" -a ${LOG_DIR} $sparkfile1 scrumologists_digital@t-mobile.com
            #echo "TransactionID - WDC OutboundTransExtract extraction Failed" | mailx -s "WDC OutboundTransExtract extraction" -a ${LOG_DIR} $sparkfile1 DL_DIFR_RECON@T-Mobile.com, SUNIL.PANDEY22@T-Mobile.com
        done
        rm -f ${LOG_DIR}WDCOutboundTransExtract.lck
        echo "Lock Released" >> ${LOG_FILE}
fi
