package com.tmobile.wdcRecon

import com.tmobile.common.{CommonMethods, GetTimeCycle, SchemaDefinitionWdc}
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import java.io.InputStreamReader
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Calendar

object WDCInboundCSVToOracle {

  //logger for WDCInboundTransExtractAdhoc Class
  @transient lazy val logger = org.apache.log4j.LogManager.getLogger(WDCInboundCSVToOracle.getClass)

  def main(args: Array[String]): Unit = {

    //<-------------------------------------     Reading Config files for transactionID -------------------------------------------------------------------------->>

    val hdfs: FileSystem = FileSystem.get(new URI(args(0)), new Configuration())
    val conf_file = new InputStreamReader(hdfs.open(new Path(args(0) + args(1)))) // reading config file
    val TransIdConstants = ConfigFactory.parseReader(conf_file)
    val conf_path = args(0)

    val json_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("CONFIG_FILE")))) // Reading json file for authentication properties
    val TransidConfig = ConfigFactory.parseReader(json_file)

    val time_conf_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("TIME_CONF"))))
    val TIME_CONF = ConfigFactory.parseReader(time_conf_file)

    CommonMethods.log4jLogGenerate(logger, TransIdConstants.getString("LOG_DIR"), "WDCInboundCSVToOracle")
    val start_time = System.nanoTime
    val timeFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
    var cal = Calendar.getInstance()
    val processed_starttime = timeFormat.format(cal.getTime).toString()

    logger.info("<----------- Inbound transaction extraction has started ---------------->")
    logger.info("Inbound transaction - extraction started on " + processed_starttime)

    //Spark session creation for WDCInboundTransExtractAdhoc application
    val conf = new SparkConf(true).setAppName("WDCInboundCSVToOracle")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
    spark.conf.set("spark.sql.parquet.int96AsTimestamp", "true")
    spark.conf.set("spark.sql.parquet.filterPushdown", "true")
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
    spark.conf.set("spark.shuffle.encryption.enabled", "true")
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration);

    //<------------------------------- Starttime endtime configuration ----------------------------------------------------------------->

    val soa_startTime = TIME_CONF.getString("startTime")
    val event_date = soa_startTime.substring(0, 10)
    val eventhr = Math.abs(soa_startTime.substring(11, 13).toInt)
    val event_hour = GetTimeCycle.generateHoursList(eventhr.max(0))
    //Source Environment Check
    val source_env_enabled = TransidConfig.getString("sourceEnabled")
    val target_env_enabled = TransidConfig.getString("targetEnabled")
    logger.info("soa_startTime " + soa_startTime)
    var dfFinal: org.apache.spark.sql.DataFrame = null
    var ReconDFOrg: org.apache.spark.sql.DataFrame = null

      var csvDataInbound = CommonMethods.readFromCSVFile(TransidConfig.getString("extract_dir.inboundCSVpath"), "|", spark, SchemaDefinitionWdc.inboundUnreconcileCsv)
      csvDataInbound=csvDataInbound.withColumn("orderid",when(lower(col("capabilityname")).isin("orderfulfillment").and(col("payload").isNotNull),regexp_extract(col("payload"),"orderId\":\"(\\d+)",1))
        when(lower(col("capabilityname")).isin("receive").and(col("payload").isNotNull),regexp_extract(col("payload"),"orderNumber\":\"(\\d+)",1))
        when(lower(col("capabilityname")).isin("orderfulfillment").and(col("sap_status_payload").isNotNull),regexp_extract(col("sap_status_payload"),"orderNumber\":\"(\\d+)",1))
        when(lower(col("capabilityname")).isin("receive").and(col("sap_status_payload").isNotNull),regexp_extract(col("sap_status_payload"),"orderNumber\":\"(\\d+)",1))
        when(lower(col("capabilityname")).isin("inventoryadjustment"),col("transactionrefno")))

   // logger.info("file read count"+csvDataInbound.count())
    dfFinal=csvDataInbound.select("location","transactionrefno","transconfirmnumber","capabilityname","apiname","digital_recon_date","warehouse_create_date","sor_recon_date",
      "digital_recon_status","wh_recon_status","sor_recon_status","recon_status","payload","sap_status_payload","orderid").dropDuplicates()
    //  logger.info(" renaming unreconciled columns "+dfFinal.filter(col("transactionrefno").isin("514511188","514611187")).show(false))

    //checking the current data in unreconciled and reconciled history
    //based on capabilityname and (transactionrefno or OrderId or Prevtransactionrefno) combination and deriving the final fields
    var dfFinalUnrecon: org.apache.spark.sql.DataFrame = null
    var dfFinalResult: org.apache.spark.sql.DataFrame = null
    // Checking whether unreconciled and reconciled history exists in mentioned path or not and then perform the logic inside clause
    logger.info("Reading unreconciled data from hdfs csv files")
    val inboundExtractOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcInboundTransactions"), target_env_enabled, TransidConfig)
    val inboundExtractArchieveOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcInboundTransactionsArchive"), target_env_enabled, TransidConfig)
    var UnReconDF =  inboundExtractOracle.filter(col("recon_status").isin("N")).union(inboundExtractArchieveOracle.filter(col("recon_status").isin("N")))
    UnReconDF=UnReconDF.withColumn("orderid",when(col("orderid").isNotNull,col("orderid")).otherwise(col("transactionrefno")))
    logger.info(" renaming unreconciled columns ")
    //renaming unreconciled columns
    UnReconDF=UnReconDF.select(col("location").as("unrecon_location"),col("transactionrefno").as("unrecon_transactionrefno"),col("transconfirmnumber").as("unrecon_transconfirmnumber"),
      col("capabilityname").as("unrecon_capabilityname"),col("apiname").as("unrecon_apiname"),col("digital_recon_date").as("unrecon_digital_recon_date"),
      col("warehouse_create_date").as("unrecon_warehouse_create_date"),col("sor_recon_date").as("unrecon_sor_recon_date"),col("digital_recon_status").as("unrecon_digital_recon_status"),
      col("wh_recon_status").as("unrecon_wh_recon_status"),col("sor_recon_status").as("unrecon_sor_recon_status"), col("recon_status").as("unrecon_recon_status"),
      col("payload").as("unrecon_payload"),col("sap_status_payload").as("unrecon_sap_status_payload"),col("prevtransactionrefno").as("unrecon_prevtransactionrefno"),col("orderid").as("unrecon_orderid"))
    //left joining the current data with unreconciled data to get history of same transcaionrefno and deriving required files
    logger.info("left joining the current data with unreconciled data")
    dfFinalUnrecon=dfFinal.join(UnReconDF,dfFinal.col("capabilityname").equalTo(UnReconDF.col("unrecon_capabilityname"))
      .and(dfFinal.col("transactionrefno").equalTo(UnReconDF.col("unrecon_transactionrefno"))),"left_outer")
   // logger.info("file read count2"+dfFinalUnrecon.count())
    //deriving required fields
    dfFinalUnrecon=dfFinalUnrecon.withColumn("location",lit("DC77"))
      .withColumn("prevtransactionrefno",col("transactionrefno"))
      .withColumn("transconfirmnumber",when(col("unrecon_transconfirmnumber").isNotNull,col("unrecon_transconfirmnumber")).otherwise(col("transconfirmnumber")))
      .withColumn("apiname",when(col("unrecon_apiname").isNotNull,col("unrecon_apiname")).otherwise(col("apiname")))
      .withColumn("digital_recon_date",when(col("unrecon_digital_recon_date").isNotNull,col("unrecon_digital_recon_date")).otherwise(col("digital_recon_date")))
      .withColumn("warehouse_create_date",when(col("unrecon_warehouse_create_date").isNotNull,col("unrecon_warehouse_create_date")).otherwise(col("warehouse_create_date")))
      .withColumn("sor_recon_date",when(col("unrecon_sor_recon_date").isNotNull.and(col("unrecon_sor_recon_status").isin("Y")),col("unrecon_sor_recon_date")).otherwise(col("sor_recon_date")))
      .withColumn("digital_recon_status",when(col("digital_recon_status").isin("Y").or(col("unrecon_digital_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
      .withColumn("wh_recon_status",when(col("wh_recon_status").isin("Y").or(col("unrecon_wh_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
      .withColumn("sor_recon_status",when(col("sor_recon_status").isin("Y").or(col("unrecon_sor_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
      .withColumn("payload",when(col("unrecon_payload").isNotNull,col("unrecon_payload")).otherwise(col("payload")))
      .withColumn("sap_status_payload",when(col("unrecon_sap_status_payload").isNotNull.and(col("unrecon_sor_recon_status").isin("Y")),col("unrecon_sap_status_payload")).otherwise(col("sap_status_payload")))
      .withColumn("orderid",when(not(col("orderid").equalTo(col("transactionrefno"))).and(trim(col("orderid")).isNotNull),col("orderid")).otherwise(col("unrecon_orderid")))

    dfFinalUnrecon=dfFinalUnrecon.withColumn("recon_status",when(col("digital_recon_status").isin("Y").and(col("wh_recon_status").isin("Y")).and(col("sor_recon_status").isin("Y"))
      ,lit("Y")).otherwise(lit("N")))
    dfFinalResult=dfFinalUnrecon.select("location","transactionrefno","transconfirmnumber","capabilityname","apiname","digital_recon_date","warehouse_create_date","sor_recon_date",
      "digital_recon_status","wh_recon_status","sor_recon_status","recon_status","payload","sap_status_payload","prevtransactionrefno","orderid").dropDuplicates()
    //logger.info("file read count3"+dfFinalResult.count())
    // Checking whether reconciled history exists in mentioned path or not and then perform the logic inside clause
    ReconDFOrg =  inboundExtractOracle.filter(col("recon_status").isin("Y")).union(inboundExtractArchieveOracle.filter(col("recon_status").isin("Y")))
    //Reading reconciled data from csv files
    logger.info("Reading reconciled data from csv files")
    ReconDFOrg=ReconDFOrg.select(col("transactionrefno").as("recon_transactionrefno"),col("capabilityname").as("recon_capabilityname"))
    //Joining current data with reconciled data to filter out if already reconciled
    logger.info("Joining current data with reconciled data to filter out if already reconciled")
    dfFinalResult=dfFinalResult.join(ReconDFOrg,dfFinalResult.col("capabilityname").equalTo(ReconDFOrg.col("recon_capabilityname"))
      .and(dfFinalResult.col("transactionrefno").equalTo(ReconDFOrg.col("recon_transactionrefno"))),"left_outer")
    dfFinalResult=dfFinalResult.filter(col("recon_capabilityname").isNull.and(col("recon_transactionrefno").isNull))
    //logger.info("file read count4"+dfFinalResult.count())
    dfFinalResult=dfFinalResult.withColumn("digital_recon_date",to_date(col("digital_recon_date"),"yyyy-MM-dd"))
      .withColumn("warehouse_create_date",to_date(col("warehouse_create_date"),"yyyy-MM-dd"))
      .withColumn("sor_recon_date",to_date(col("sor_recon_date"),"yyyy-MM-dd"))
    dfFinalResult=dfFinalResult.withColumn("orderid",when(lower(col("capabilityname")).isin("inventoryadjustment")
      .or(col("transactionrefno").equalTo(col("orderid"))),lit("")).otherwise(col("orderid")))
    val windowSpecIntial = Window.partitionBy("transactionrefno","capabilityname").orderBy(desc("recon_status"),desc("digital_recon_status"),desc("wh_recon_status"),desc("sor_recon_status"),desc("digital_recon_date"),desc("warehouse_create_date"),desc("sor_recon_date"))
    dfFinalResult=dfFinalResult.withColumn("rowNumber",row_number().over(windowSpecIntial))
    dfFinalResult=dfFinalResult.filter(col("rowNumber").equalTo(1))
    dfFinalResult=dfFinalResult.filter(col("transactionrefno").isNotNull.and(col("capabilityname").isNotNull))
    dfFinalResult = dfFinalResult.withColumn("recon_create_date",least(col("digital_recon_date"),col("warehouse_create_date"),col("sor_recon_date")))
    dfFinalResult=dfFinalResult.select("location","transactionrefno","transconfirmnumber","capabilityname","apiname","digital_recon_date","warehouse_create_date","sor_recon_date",
      "digital_recon_status","wh_recon_status","sor_recon_status","recon_status","payload","sap_status_payload","prevtransactionrefno","orderid","recon_create_date")
    //logger.info("file read count5"+dfFinalResult.count())
    val dbtable=TransidConfig.getString("oracle_target.wdcInboundTransactions")
    val temptable=TransidConfig.getString("oracle_target.wdcInboundTransactionsTemp")
    val upsertQuery= s""" MERGE INTO $dbtable target USING $temptable source
          on (target.transactionrefno=source.transactionrefno
          and target.capabilityname=source.capabilityname)
          WHEN MATCHED THEN UPDATE SET
					target.LOCATION=source.LOCATION ,
					target.TRANSCONFIRMNUMBER=source.TRANSCONFIRMNUMBER ,
					target.APINAME=source.APINAME ,
					target.DIGITAL_RECON_DATE=source.DIGITAL_RECON_DATE ,
					target.WAREHOUSE_CREATE_DATE=source.WAREHOUSE_CREATE_DATE ,
					target.SOR_RECON_DATE=source.SOR_RECON_DATE ,
					target.DIGITAL_RECON_STATUS=source.DIGITAL_RECON_STATUS ,
					target.WH_RECON_STATUS=source.WH_RECON_STATUS ,
					target.SOR_RECON_STATUS=source.SOR_RECON_STATUS ,
					target.RECON_STATUS=source.RECON_STATUS ,
					target.PAYLOAD=source.PAYLOAD ,
					target.SAP_STATUS_PAYLOAD=source.SAP_STATUS_PAYLOAD ,
					target.PREVTRANSACTIONREFNO =source.PREVTRANSACTIONREFNO,
					target.ORDERID=source.ORDERID
					WHEN NOT MATCHED THEN INSERT (LOCATION , TRANSACTIONREFNO , TRANSCONFIRMNUMBER , CAPABILITYNAME , APINAME , DIGITAL_RECON_DATE , WAREHOUSE_CREATE_DATE , SOR_RECON_DATE , DIGITAL_RECON_STATUS , WH_RECON_STATUS , SOR_RECON_STATUS , RECON_STATUS , PAYLOAD , SAP_STATUS_PAYLOAD , PREVTRANSACTIONREFNO , ORDERID, RECON_CREATE_DATE)
					VALUES (source.LOCATION , source.TRANSACTIONREFNO , source.TRANSCONFIRMNUMBER , source.CAPABILITYNAME , source.APINAME , source.DIGITAL_RECON_DATE , source.WAREHOUSE_CREATE_DATE , source.SOR_RECON_DATE , source.DIGITAL_RECON_STATUS , source.WH_RECON_STATUS , source.SOR_RECON_STATUS , source.RECON_STATUS , source.PAYLOAD , source.SAP_STATUS_PAYLOAD , source.PREVTRANSACTIONREFNO , source.ORDERID, source.RECON_CREATE_DATE)"""
    CommonMethods.saveToJDBC(dfFinalResult, TransidConfig.getString("oracle_target.wdcInboundTransactionsTemp"), "overwrite", target_env_enabled, TransidConfig)
    CommonMethods.saveJDBC(target_env_enabled, TransidConfig, upsertQuery)

    val end_time = System.nanoTime
    logger.info("WDC Inbound transaction - extraction completed on " + end_time)
    //logger.info("WDC Inbound transaction - extraction next run starttime is" + nextcycletime)
    //logger.info("WDC Inbound transaction - extraction processed endtime is" + processed_endtime)
    logger.info("WDC Inbound transaction - extraction total time taken " + ((end_time - start_time) / 1e9d) + " seconds")
    logger.info("<----------- WDC Inbound transaction extraction has completed ---------------->")

    spark.close()
    spark.stop()
  }

}