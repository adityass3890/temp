package com.tmobile.wdcRecon

import com.tmobile.common.{CommonMethods, GetTimeCycle, SchemaDefinitionWdc}
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import java.io.InputStreamReader
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Calendar

object WDCOutboundCSVToOracle {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger(WDCOutboundCSVToOracle.getClass)

  def main(args: Array[String]): Unit = {

    //<-------------------------------------     Reading Config files for transactionID -------------------------------------------------------------------------->>

    val hdfs: FileSystem = FileSystem.get(new URI(args(0)), new Configuration())
    val conf_file = new InputStreamReader(hdfs.open(new Path(args(0) + args(1)))) //"TRANSID_CommonConstants.conf"
    val TransIdConstants = ConfigFactory.parseReader(conf_file)

    val json_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("CONFIG_FILE"))))
    val TransidConfig = ConfigFactory.parseReader(json_file)

    val time_conf_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("OUT_TIME_CONF"))))
    val TIME_CONF = ConfigFactory.parseReader(time_conf_file)

    CommonMethods.log4jLogGenerate(logger, TransIdConstants.getString("LOG_DIR"), "WDCOutboundCSVToOracle")
    val start_time = System.nanoTime
    val timeFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
    var cal = Calendar.getInstance()
    val processed_starttime = timeFormat.format(cal.getTime).toString()

    logger.info("<----------- Outbound transaction extraction has started ---------------->")
    logger.info("Outbound transaction - extraction started on " + processed_starttime)

    val conf = new SparkConf(true).setAppName("WDCOutboundCSVToOracle")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
    spark.conf.set("spark.sql.parquet.int96AsTimestamp", "true")
    spark.conf.set("spark.sql.parquet.filterPushdown", "true")
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
    spark.conf.set("spark.shuffle.encryption.enabled", "true")
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration);

    //<------------------------------- Starttime endtime configuration ----------------------------------------------------------------->

    val soa_startTime = TIME_CONF.getString("startTime")
    val event_date = soa_startTime.substring(0, 10)
    val eventhr = Math.abs(soa_startTime.substring(11, 13).toInt)
    val event_hour = GetTimeCycle.generateHoursList(eventhr.max(0))
    //Source Environment Check
    val source_env_enabled = TransidConfig.getString("sourceEnabled")
    val target_env_enabled = TransidConfig.getString("targetEnabled")

    logger.info("soa_startTime " + soa_startTime)
    var dfDigital: org.apache.spark.sql.DataFrame = null
    var dfWarehouse: org.apache.spark.sql.DataFrame = null
    var dfJoinDigWare: org.apache.spark.sql.DataFrame = null
    var dfFinal: org.apache.spark.sql.DataFrame = null
    var dftime: org.apache.spark.sql.DataFrame = null
    var ReconDFOrg: org.apache.spark.sql.DataFrame = null

    val keyspace= "cassandra_source."+TransidConfig.getString("sourceEnabled")+".keyspace"
    var csvDataOutbound = CommonMethods.readFromCSVFile(TransidConfig.getString("extract_dir.outboundCSVpath"), "|", spark, SchemaDefinitionWdc.outboundUnreconcileCsv)
    csvDataOutbound=csvDataOutbound.withColumn("orderid",when(lower(col("apiname")).isin("outboundorder").and(col("payload").isNotNull),regexp_extract(col("payload"),"hostOrderId\":\"(\\d+)",1))
      when(lower(col("apiname")).isin("inboundorder").and(col("payload").isNotNull),regexp_extract(col("payload"),"orderNumber\":\"(\\d+)",1))
      when(lower(col("apiname")).isin("outboundorder","inboundorder").and(col("warehouse_payload").isNotNull),regexp_extract(col("warehouse_payload"),"orderNumber\":\"(\\d+)",1))
      when(lower(col("capabilityname")).isin("foundation"),col("transactionrefno")))
   // logger.info("file read count"+csvDataOutbound.count())
    //  logger.info(" renaming unreconciled columns before"+dfJoinDigSapWare.filter(col("transactionrefno").isin("514511188","514611187")).show(false))

    csvDataOutbound=csvDataOutbound.withColumn("orderid",when(trim(col("orderid")).isNull.or(trim(col("orderid")).isin("")),col("transactionrefno")).otherwise(col("orderid")))

    dfFinal=csvDataOutbound.select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status","wh_recon_status","recon_status","payload","warehouse_payload","orderid")
    dfFinal=dfFinal.dropDuplicates()

   // var checkDf=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactions"), target_env_enabled, TransidConfig," select * from "+TransidConfig.getString("oracle_target.wdcOutboundTransactions")+" fetch first 1 rows only")

    //checking the current data in unreconciled and reconciled history
    // based on capabilityname and (transactionrefno or OrderId or Prevtransactionrefno) combination and deriving the final fields
    var dfFinalUnrecon: org.apache.spark.sql.DataFrame = null
    var dfFinalUnreconRight: org.apache.spark.sql.DataFrame = null
    var dfFinalRight: org.apache.spark.sql.DataFrame = null
    var dfFinalResult: org.apache.spark.sql.DataFrame = null
    // Checking whether unreconciled and reconciled history exists in mentioned path or not and then perform the logic inside clause
      val outboundExtractOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactions"), target_env_enabled, TransidConfig)
      val outboundExtractArchieveOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactionsArchive"), target_env_enabled, TransidConfig)
      var UnReconDF =  outboundExtractOracle.filter(col("recon_status").isin("N")).union(outboundExtractArchieveOracle.filter(col("recon_status").isin("N")))
      //unreconcile data right join to get previous unreconcile data
      dfFinalRight=dfFinal.withColumnRenamed("transactionrefno","dfright_transactionrefno").withColumnRenamed("apiname","dfright_apiname")
        .select("dfright_transactionrefno","dfright_apiname")
      dfFinalUnreconRight=dfFinalRight.join(UnReconDF,dfFinalRight.col("dfright_apiname").equalTo(UnReconDF.col("apiname"))
        .and(dfFinalRight.col("dfright_transactionrefno").equalTo(UnReconDF.col("transactionrefno"))),"right_outer")
      dfFinalUnreconRight=dfFinalUnreconRight.filter(col("dfright_apiname").isNull.and(col("dfright_transactionrefno").isNull))
        .select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status",
          "wh_recon_status","recon_status","payload","warehouse_payload","orderid")
      //unreconcile data left join to get current unreconcile data
      UnReconDF=UnReconDF.select(col("capabilityname").as("unrecon_capabilityname"),col("apiname").as("unrecon_apiname"),col("transactionrefno").as("unrecon_transactionrefno"),
        col("digital_recon_date").as("unrecon_digital_recon_date"),col("warehouse_recon_date").as("unrecon_warehouse_recon_date"),col("digital_recon_status").as("unrecon_digital_recon_status"),
        col("wh_recon_status").as("unrecon_wh_recon_status"),col("recon_status").as("unrecon_recon_status"),col("payload").as("unrecon_payload"),col("warehouse_payload").as("unrecon_warehouse_payload"),col("orderid").as("unrecon_orderid"))
      //left joining the current data with unreconciled data to get history of same transcaionrefno and deriving required files
      logger.info("left joining the current data with unreconciled data to get history of same transcaionrefno and deriving required files")
      dfFinalUnrecon=dfFinal.join(UnReconDF,dfFinal.col("apiname").equalTo(UnReconDF.col("unrecon_apiname"))
        .and(dfFinal.col("transactionrefno").equalTo(UnReconDF.col("unrecon_transactionrefno"))),"left_outer")
   // logger.info("file read count2"+dfFinalUnrecon.count())
      dfFinalUnrecon=dfFinalUnrecon
        .withColumn("prevtransactionrefno",col("transactionrefno"))
        .withColumn("capabilityname",when(col("capabilityname").isNotNull,col("capabilityname")).otherwise(col("unrecon_capabilityname")))
        .withColumn("apiname",when(col("apiname").isNotNull,col("apiname")).otherwise(col("unrecon_apiname")))
        .withColumn("digital_recon_date",when(col("digital_recon_date").isNotNull,col("digital_recon_date")).otherwise(col("unrecon_digital_recon_date")))
        .withColumn("warehouse_recon_date",when(col("warehouse_recon_date").isNotNull,col("warehouse_recon_date")).otherwise(col("unrecon_warehouse_recon_date")))
        .withColumn("digital_recon_status",when(col("digital_recon_status").isin("Y").or(col("unrecon_digital_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
        .withColumn("wh_recon_status",when(col("wh_recon_status").isin("Y").or(col("unrecon_wh_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
        .withColumn("payload",when(col("payload").isNotNull,col("payload")).otherwise(col("unrecon_payload")))
        .withColumn("orderid",when(not(col("orderid").equalTo(col("transactionrefno"))).and(trim(col("orderid")).isNotNull),col("orderid")).otherwise(col("unrecon_orderid")))
        .withColumn("warehouse_payload",when(col("warehouse_payload").isNotNull,col("warehouse_payload")).otherwise(col("unrecon_warehouse_payload")))
      dfFinalUnrecon=dfFinalUnrecon.withColumn("recon_status",when(col("digital_recon_status").isin("Y").and(col("wh_recon_status").isin("Y"))
        ,lit("Y")).otherwise(lit("N")))
      dfFinalResult=dfFinalUnrecon.select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status",
        "wh_recon_status","recon_status","payload","warehouse_payload","prevtransactionrefno","orderid")
   // logger.info("file read count3"+dfFinalResult.count())
      // Checking whether reconciled history exists in mentioned path or not and then perform the logic inside clause
      //Reading reconciled data from csv files
      // ReconDFOrg = CommonMethods.readFromCSVFile(TransidConfig.getString("extract_dir.OutboundReconcileExtract"), "|", spark, SchemaDefinitionWdc.outboundUnreconcile)
      ReconDFOrg =  outboundExtractOracle.filter(col("recon_status").isin("Y")).union(outboundExtractArchieveOracle.filter(col("recon_status").isin("Y")))
      ReconDFOrg = ReconDFOrg.select(col("capabilityname").as("recon_capabilityname"),col("apiname").as("recon_apiname"),col("transactionrefno").as("recon_transactionrefno"),col("digital_recon_date").as("recon_digital_recon_date"),
        col("warehouse_recon_date").as("recon_warehouse_recon_date"),col("digital_recon_status").as("recon_digital_recon_status"),col("wh_recon_status").as("recon_wh_recon_status"),
        col("recon_status").as("recon_recon_status"),col("payload").as("recon_payload"), col("warehouse_payload").as("recon_warehouse_payload"),col("orderid").as("recon_orderid"))
      //Joining current data with reconciled data
      logger.info("Joining current data with reconciled data ")
      dfFinalResult = dfFinalResult.join(ReconDFOrg, ReconDFOrg.col("recon_transactionrefno").equalTo(dfFinalResult.col("transactionrefno"))
        .and(ReconDFOrg.col("recon_apiname").equalTo(dfFinalResult.col("apiname"))), "left_outer")
      dfFinalResult=dfFinalResult.filter(col("recon_capabilityname").isNull.and(col("recon_transactionrefno").isNull))
   // logger.info("file read count4"+dfFinalResult.count())
      dfFinalResult=dfFinalResult.withColumn("digital_recon_date",to_date(col("digital_recon_date"),"yyyy-MM-dd"))
        .withColumn("warehouse_recon_date",to_date(col("warehouse_recon_date"),"yyyy-MM-dd"))
      val windowSpecIntial = Window.partitionBy("capabilityname","transactionrefno").orderBy(desc("recon_status"),desc("digital_recon_status"),desc("wh_recon_status"),desc("digital_recon_date"),desc("warehouse_recon_date"))
      dfFinalResult=dfFinalResult.withColumn("rowNumber",row_number().over(windowSpecIntial))
      dfFinalResult=dfFinalResult.filter(col("rowNumber").equalTo(1)).dropDuplicates("transactionrefno","capabilityname")
      dfFinalResult=dfFinalResult.filter(col("transactionrefno").isNotNull.and(col("capabilityname").isNotNull))
      dfFinalResult = dfFinalResult.select("capabilityname", "apiname", "transactionrefno", "digital_recon_date", "warehouse_recon_date", "digital_recon_status",
        "wh_recon_status", "recon_status", "payload", "warehouse_payload","prevtransactionrefno","orderid")
      logger.info("Joining current data with reconciled data "+dfFinalResult.printSchema())
      dfFinalResult = dfFinalResult.withColumn("recon_create_date",least(col("digital_recon_date"),col("warehouse_recon_date")))
    //logger.info("file read count5"+dfFinalResult.count())
      val dbtable=TransidConfig.getString("oracle_target.wdcOutboundTransactions")
      val temptable=TransidConfig.getString("oracle_target.wdcOutboundTransactionsTemp")
      val upsertQuery= s""" MERGE INTO $dbtable target USING $temptable source
          on (target.transactionrefno=source.transactionrefno
          and target.capabilityname=source.capabilityname)
          WHEN MATCHED THEN UPDATE SET
					target.APINAME=source.APINAME ,
					target.DIGITAL_RECON_DATE=source.DIGITAL_RECON_DATE ,
					target.WAREHOUSE_RECON_DATE=source.WAREHOUSE_RECON_DATE ,
					target.DIGITAL_RECON_STATUS=source.DIGITAL_RECON_STATUS ,
					target.WH_RECON_STATUS=source.WH_RECON_STATUS ,
					target.RECON_STATUS=source.RECON_STATUS ,
					target.PAYLOAD=source.PAYLOAD ,
					target.WAREHOUSE_PAYLOAD=source.WAREHOUSE_PAYLOAD ,
          target.PREVTRANSACTIONREFNO=source.PREVTRANSACTIONREFNO ,
					target.ORDERID=source.ORDERID
					WHEN NOT MATCHED THEN INSERT (CAPABILITYNAME,APINAME,TRANSACTIONREFNO,DIGITAL_RECON_DATE,WAREHOUSE_RECON_DATE,DIGITAL_RECON_STATUS,WH_RECON_STATUS,RECON_STATUS,PAYLOAD,WAREHOUSE_PAYLOAD,PREVTRANSACTIONREFNO,ORDERID,RECON_CREATE_DATE)
					VALUES (source.CAPABILITYNAME,source.APINAME,source.TRANSACTIONREFNO,source.DIGITAL_RECON_DATE,source.WAREHOUSE_RECON_DATE,source.DIGITAL_RECON_STATUS,source.WH_RECON_STATUS,source.RECON_STATUS,source.PAYLOAD,source.WAREHOUSE_PAYLOAD,source.PREVTRANSACTIONREFNO,source.ORDERID,source.RECON_CREATE_DATE)"""
      CommonMethods.saveToJDBC(dfFinalResult, TransidConfig.getString("oracle_target.wdcOutboundTransactionsTemp"), "overwrite", target_env_enabled, TransidConfig)
      CommonMethods.saveJDBC(target_env_enabled, TransidConfig, upsertQuery)


    logger.info(" Updating next cycle timestamp in time conf")

    val end_time = System.nanoTime
    logger.info("WDC Outbound transaction - extraction completed on " + end_time)
    logger.info("WDC Outbound transaction - extraction total time taken " + ((end_time - start_time) / 1e9d) + " seconds")
    logger.info("<----------- WDC Outbound transaction extraction has completed ---------------->")

    spark.close()
    spark.stop()
  }

}