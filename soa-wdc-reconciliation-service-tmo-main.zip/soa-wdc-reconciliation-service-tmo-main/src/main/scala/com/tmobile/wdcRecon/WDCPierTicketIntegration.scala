package com.tmobile.wdcRecon

import com.tmobile.common.{CommonMethods, GetTimeCycle, SchemaDefinitionWdc}
import com.tmobile.wdcRecon.WDCInboundTransExtract.logger
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.{DataFrame, Encoders, Row, SparkSession, functions}
import org.apache.spark.storage.StorageLevel

import java.io.{InputStreamReader, PrintWriter}
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

object WDCPierTicketIntegration {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger(WDCPierTicketIntegration.getClass)

  def main(args: Array[String]): Unit = {
    //<-------------------------------------     Reading Config files -------------------------------------------------------------------------->>
    val hdfs: FileSystem = FileSystem.get(new URI(args(0)), new Configuration())
    val conf_file = new InputStreamReader(hdfs.open(new Path(args(0) + args(1))))  // reading config file
    val TransIdConstants = ConfigFactory.parseReader(conf_file) //Reading config constants

    val json_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("CONFIG_FILE")))) // Reading json file for authentication properties
    val TransidConfig = ConfigFactory.parseReader(json_file)

    CommonMethods.log4jLogGenerate(logger, TransIdConstants.getString("LOG_DIR"), "WDCpierTicketIntegration")
    val start_time = System.nanoTime
    val timeFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
    val dateFormat = new SimpleDateFormat("YYYY-MM-dd")
    var cal = Calendar.getInstance()
    val processed_starttime = timeFormat.format(cal.getTime).toString()
    val cycle_no = GetTimeCycle.cycle_no
    val file_date = GetTimeCycle.file_date

    logger.info("<----------- WDCPierTicketIntegration extraction has started ---------------->")
    logger.info("WDCPierTicketIntegration - extraction started on " + processed_starttime)

    //Spark session creation for WDCInboundTransExtractAdhoc application
    val conf = new SparkConf(true).setAppName("WDCPierTicketIntegration")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
    spark.conf.set("spark.sql.parquet.int96AsTimestamp", "true")
    spark.conf.set("spark.sql.parquet.filterPushdown", "true")
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
    spark.conf.set("spark.shuffle.encryption.enabled", "true")
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
    import spark.implicits._
    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration)

    //Source Environment Check
    val target_env_enabled = TransidConfig.getString("targetEnabled")

    var pierticketProcessingDF = CommonMethods.readFromCSVFile(TransidConfig.getString("extract_dir.pierTicketProcessing"), ",", spark, SchemaDefinitionWdc.pierTicketProcessing)
    pierticketProcessingDF = pierticketProcessingDF.withColumn("Process", when(col("TRANSREFNO").isNull || col("CAPABILITYNAME").isNull || col("PIER_TICKETNUMBER").isNull,"N").when(col("PIER_TICKETSTATUS").isin("CLOSED").and(col("PIER_TICKETCLOSEDATE").isNull),"N").otherwise("Y"))
      .withColumn("ProcessNotes", when(col("TRANSREFNO").isNull || col("CAPABILITYNAME").isNull || col("PIER_TICKETNUMBER").isNull,"Invalid Record").when(col("PIER_TICKETSTATUS").isin("CLOSED").and(col("PIER_TICKETCLOSEDATE").isNull),"Invalid Closing Date").otherwise(""))
    var pierticketProcessingJson = pierticketProcessingDF.filter(col("Process")===("Y")).withColumn("UPDATES",to_json(struct($"*"))).withColumn("PIER_TICKETOPENDATE",when(col("PIER_TICKETOPENDATE").isNotNull,concat(substring(col("PIER_TICKETOPENDATE"),1,4),lit("-"),substring(col("PIER_TICKETOPENDATE"),5,2),lit("-"),substring(col("PIER_TICKETOPENDATE"),7,2))).otherwise(lit(null))).withColumn("PIER_TICKETCLOSEDATE",when(col("PIER_TICKETCLOSEDATE").isNotNull,concat(substring(col("PIER_TICKETCLOSEDATE"),1,4),lit("-"),substring(col("PIER_TICKETCLOSEDATE"),5,2),lit("-"),substring(col("PIER_TICKETCLOSEDATE"),7,2))).otherwise(lit(null))).withColumn("PIER_TICKETOPENDATE",to_date(col("PIER_TICKETOPENDATE"),"yyyy-MM-dd")).withColumn("PIER_TICKETCLOSEDATE",to_date(col("PIER_TICKETCLOSEDATE"),"yyyy-MM-dd"))
    pierticketProcessingJson = pierticketProcessingJson.select("TRANSREFNO","TRANSCONFNO","CAPABILITYNAME","PIER_TICKETNUMBER","PIER_TICKETOPENDATE","PIER_TICKETSTATUS","PIER_TICKETCLOSEDATE","COMMENTS","RECON_FLAG","UPDATES")
    val dbtable=TransidConfig.getString("oracle_target.wdcPierTicket")
    val temptable=TransidConfig.getString("oracle_target.wdcPierTicketTemp")
    val upsertQuery= s""" MERGE INTO $dbtable target USING $temptable source
          on (target.TRANSREFNO=source.TRANSREFNO
          and target.CAPABILITYNAME=source.CAPABILITYNAME)
          WHEN MATCHED THEN UPDATE SET
					target.COMMENTS=source.COMMENTS ,
          target.TRANSCONFNO=source.TRANSCONFNO ,
          target.PIER_TICKETCLOSEDATE=source.PIER_TICKETCLOSEDATE ,
					target.PIER_TICKETSTATUS=source.PIER_TICKETSTATUS ,
					target.PIER_TICKETNUMBER=source.PIER_TICKETNUMBER ,
					target.PIER_TICKETOPENDATE=source.PIER_TICKETOPENDATE ,
          target.RECON_FLAG=source.RECON_FLAG,
					target.UPDATES= (\'[\' || substr(target.UPDATES,2, length(target.UPDATES)-2) ||\',\' || source.UPDATES|| \']\')
					WHEN NOT MATCHED THEN INSERT (TRANSREFNO,TRANSCONFNO,CAPABILITYNAME,PIER_TICKETNUMBER,PIER_TICKETOPENDATE,PIER_TICKETSTATUS,PIER_TICKETCLOSEDATE,COMMENTS,RECON_FLAG,UPDATES)
					VALUES (source.TRANSREFNO,source.TRANSCONFNO,source.CAPABILITYNAME,source.PIER_TICKETNUMBER,source.PIER_TICKETOPENDATE,source.PIER_TICKETSTATUS,source.PIER_TICKETCLOSEDATE,source.COMMENTS,source.RECON_FLAG,\'[\' ||source.UPDATES || \']\')"""
    CommonMethods.saveToJDBC(pierticketProcessingJson, TransidConfig.getString("oracle_target.wdcPierTicketTemp"), "overwrite", target_env_enabled, TransidConfig)
    CommonMethods.saveJDBC(target_env_enabled, TransidConfig, upsertQuery)
    val errorsDf=pierticketProcessingDF.filter(col("Process").isin("N"))
    CommonMethods.writeToCSVFile(errorsDf, ",",TransidConfig.getString("extract_dir.pierTicketErrors"), "overwrite")
    CommonMethods.copyContents(TransidConfig.getString("extract_dir.pierTicketErrors"), TransidConfig.getString("extract_dir.pierTicketErrors"), "part*",
      "wdc_pierticket_error_" + file_date+"_"+cycle_no + ".csv", "rename")
    val processedDf=pierticketProcessingDF.filter(col("Process").isin("Y"))
    CommonMethods.writeToCSVFile(processedDf, ",",TransidConfig.getString("extract_dir.pierTicketProcessed"), "overwrite")
    CommonMethods.copyContents(TransidConfig.getString("extract_dir.pierTicketProcessed"), TransidConfig.getString("extract_dir.pierTicketProcessed"), "part*",
      "wdc_pierticket_processed_" + file_date+"_"+cycle_no + ".csv", "rename")

    ///// File name update in hdfs
    val output = fileSystem.create(new Path(TransidConfig.getString("extract_dir.pierProcessedFileName")), true)
    val writer = new PrintWriter(output)
    writer.write("wdc_piertciket_processed_" + file_date+"_"+cycle_no + ".csv")
    writer.close()

    val output2 = fileSystem.create(new Path(TransidConfig.getString("extract_dir.pierErrorFileName")), true)
    val writer2 = new PrintWriter(output2)
    writer2.write("wdc_pierticket_error_" + file_date+"_"+cycle_no + ".csv")
    writer2.close()

    val end_time = System.nanoTime
    logger.info("WDCPierTicketIntegration - extraction completed on " + end_time)
    logger.info("WDCPierTicketIntegration - extraction total time taken " + ((end_time - start_time) / 1e9d) + " seconds")
    logger.info("<----------- WDCPierTicketIntegration extraction has completed ---------------->")

    spark.close()
    spark.stop()
  }


}