package com.tmobile.wdcRecon

import com.tmobile.common.{CommonMethods, GetTimeCycle, SchemaDefinitionWdc}
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import java.io.{InputStreamReader, PrintWriter}
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Calendar

object WDCOutboundTransExtract {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger(WDCOutboundTransExtract.getClass)

  def main(args: Array[String]): Unit = {

    //<-------------------------------------     Reading Config files for transactionID -------------------------------------------------------------------------->>

    val hdfs: FileSystem = FileSystem.get(new URI(args(0)), new Configuration())
    val conf_file = new InputStreamReader(hdfs.open(new Path(args(0) + args(1)))) //"TRANSID_CommonConstants.conf"
    val TransIdConstants = ConfigFactory.parseReader(conf_file)

    val json_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("CONFIG_FILE"))))
    val TransidConfig = ConfigFactory.parseReader(json_file)

    val time_conf_file = new InputStreamReader(hdfs.open(new Path(TransIdConstants.getString("OUT_TIME_CONF"))))
    val TIME_CONF = ConfigFactory.parseReader(time_conf_file)

    CommonMethods.log4jLogGenerate(logger, TransIdConstants.getString("LOG_DIR"), "WDCOutboundTransExtract")
    val start_time = System.nanoTime
    val timeFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
    var cal = Calendar.getInstance()
    val processed_starttime = timeFormat.format(cal.getTime).toString()

    logger.info("<----------- Outbound transaction extraction has started ---------------->")
    logger.info("Outbound transaction - extraction started on " + processed_starttime)

    val conf = new SparkConf(true).setAppName("WDCOutboundTransExtract")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
    spark.conf.set("spark.sql.parquet.int96AsTimestamp", "true")
    spark.conf.set("spark.sql.parquet.filterPushdown", "true")
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
    spark.conf.set("spark.shuffle.encryption.enabled", "true")
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

    val fileSystem = FileSystem.get(spark.sparkContext.hadoopConfiguration);

    //<------------------------------- Starttime endtime configuration ----------------------------------------------------------------->

    val soa_startTime = TIME_CONF.getString("startTime")
    val event_date = soa_startTime.substring(0, 10)
    val eventhr = Math.abs(soa_startTime.substring(11, 13).toInt)
    val event_hour = GetTimeCycle.generateHoursList(eventhr.max(0))
    //Source Environment Check
    val source_env_enabled = TransidConfig.getString("sourceEnabled")
    val target_env_enabled = TransidConfig.getString("targetEnabled")

    logger.info("soa_startTime " + soa_startTime)
    var dfDigital: org.apache.spark.sql.DataFrame = null
    var dfWarehouse: org.apache.spark.sql.DataFrame = null
    var dfJoinDigWare: org.apache.spark.sql.DataFrame = null
    var dfFinal: org.apache.spark.sql.DataFrame = null
    var dftime: org.apache.spark.sql.DataFrame = null
    var ReconDFOrg: org.apache.spark.sql.DataFrame = null

    val keyspace= "cassandra_source."+TransidConfig.getString("sourceEnabled")+".keyspace"
    for (event_hr <- event_hour) {

      //<-------------------------------------     reading data from Cassandra -------------------------------------------------------------------------->>
      logger.info("Reading the data from outboundtransactionlogv2 Cassandra Table by passing below query")
      //Reading the data from "outboundtransactionlogv2" Cassandra Table by passing below query
      val digitalQuery="select eventdate,outboundapirequestpayload,soacapabilityname,outboundapiname,invokingsystemtransactionrefno from mycatalog."+TransidConfig.getString(keyspace)+".outboundtransactionlogv2 " +
        "where eventdate='"+event_date+"' and eventhour="+event_hr.max(0) +
        " and outboundapiname in ('DC77-InboundOrderCreate', 'DC77-OutboundDeliveryOrderCreate', 'DC77-ItemMasterAPICREATE', 'DC77-InboundOrderUpdate', 'DC77-ItemMasterAPICHANGE', 'DC77-ItemMasterAPIDELETE')"
      dfDigital = CommonMethods.readCassandraTableQuery("outboundtransactionlogv2", source_env_enabled, TransidConfig,digitalQuery)

      //deriving outboundapiname and replacing new alines ,| 's with blank for payload field
      dfDigital = dfDigital.withColumn("outboundapirequestpayload", regexp_replace(col("outboundapirequestpayload"), "\n", " "))
      dfDigital = dfDigital.withColumn("outboundapirequestpayload", regexp_replace(col("outboundapirequestpayload"), "\\|", " "))
        .withColumn("outboundapiname", when(lower(col("outboundapiname")).contains("itemmaster"), lit("ItemMaster"))
          when(lower(col("outboundapiname")).contains("inboundorder"), lit("InboundOrder"))
          when(lower(col("outboundapiname")).contains("outboundorder").or(lower(col("outboundapiname")).contains("outbound")), lit("OutboundOrder")))

      logger.info("Reading the data from transactionnotificationlogv3 Cassandra Table by passing below query")
      //Reading the data from "transactionnotificationlogv3-warehouse" Cassandra Table by passing below query
      val dfWarehouseQuery="select eventdate, eventhour, eventorigin, eventname, apiname, transactionrefno, transconfirmnumber, invocationtype, apitransactionrefno,apitransconfirmnumber, createdtimestamp, eventaction, eventattributelist, eventdestination, transactionlineitems" +
        " from mycatalog."+TransidConfig.getString(keyspace)+".transactionnotificationlogv3 where eventdate='"+event_date+"' and eventhour="+event_hr.max(0)+" and eventorigin in ('DC77') " +
        "and eventname in ('Transfer', 'Foundation') and apiname in ('ItemMaster', 'InboundOrder', 'OutboundOrder')"
      dfWarehouse = CommonMethods.readCassandraTableQuery("transactionnotificationlogv3", source_env_enabled, TransidConfig,dfWarehouseQuery)
      //transactionlineitems convertion in proper json format and concating with event attributelist
      dfWarehouse=dfWarehouse.withColumn("transactionlineitems",to_json(struct(col("transactionlineitems")))).withColumn("eventattributelist",to_json(struct(col("eventattributelist"))))
      dfWarehouse=dfWarehouse.withColumn("transactionlineitems",regexp_replace(col("transactionlineitems"),".$",""))
      dfWarehouse=dfWarehouse.withColumn("eventattributelist",regexp_replace(col("eventattributelist").cast("String"),"^.",""))
      dfWarehouse = dfWarehouse.withColumn("transactionlineitemsstatus", when(lower(dfWarehouse.col("transactionlineitems").cast("String")).contains("success"), lit("success"))
        when(lower(dfWarehouse.col("transactionlineitems").cast("String")).contains("fail").or(dfWarehouse.col("transactionlineitems").isNull), lit("fail")))

      // To check whether sap_payload is having success and fail entries in current data and prefer success over fail
      val windowSpec = Window.partitionBy("apitransactionrefno", "eventname").orderBy(desc("transactionlineitemsstatus"))
      dfWarehouse = dfWarehouse.withColumn("rowNumber", row_number().over(windowSpec))
      dfWarehouse = dfWarehouse.filter(col("rowNumber").equalTo(1))

    }

    //Full Joining the Digital and Warehouse data based on capabilityname and transactionrefno and deriving the required fields
    dfJoinDigWare=dfDigital.join(dfWarehouse,dfDigital.col("outboundapiname").equalTo(dfWarehouse.col("apiname"))
        .and(dfDigital.col("invokingsystemtransactionrefno").equalTo(dfWarehouse.col("apitransactionrefno"))),"full_outer")
      .withColumn("capabilityname", when(dfDigital.col("soacapabilityname").isNull,dfWarehouse.col("eventname")).otherwise(dfDigital.col("soacapabilityname")))
      .withColumn("apiname", when(dfDigital.col("outboundapiname").isNull,dfWarehouse.col("apiname")).otherwise(dfDigital.col("outboundapiname")))
      .withColumn("transactionrefno", when(dfDigital.col("invokingsystemtransactionrefno").isNull,dfWarehouse.col("apitransactionrefno")).otherwise(dfDigital.col("invokingsystemtransactionrefno")))
      .withColumn("digital_recon_date", dfDigital.col("eventdate"))
      .withColumn("warehouse_recon_date", dfWarehouse.col("eventdate"))
      .withColumn("digital_recon_status", when(dfDigital.col("eventdate").isNull,lit("N")).otherwise(lit("Y")))
      .withColumn("wh_recon_status", when(dfWarehouse.col("eventdate").isNull.or(lower(dfWarehouse.col("transactionlineitems").cast("String")).contains("fail")),lit("N")).otherwise(lit("Y")))
      .withColumn("recon_status", when(dfDigital.col("eventdate").isNull.or(dfWarehouse.col("eventdate").isNull),lit("N")).otherwise(lit("Y")))
      .withColumn("payload", dfDigital.col("outboundapirequestpayload"))
      .withColumn("warehouse_payload", concat(dfWarehouse.col("transactionlineitems"),lit(","),dfWarehouse.col("eventattributelist")))


    dfJoinDigWare=dfJoinDigWare.withColumn("orderid",when(lower(col("apiname")).isin("outboundorder").and(col("payload").isNotNull),regexp_extract(col("payload"),"hostOrderId\":\"(\\d+)",1))
      when(lower(col("apiname")).isin("inboundorder").and(col("payload").isNotNull),regexp_extract(col("payload"),"orderNumber\":\"(\\d+)",1))
      when(lower(col("apiname")).isin("outboundorder","inboundorder").and(col("warehouse_payload").isNotNull),regexp_extract(col("warehouse_payload"),"orderNumber\":\"(\\d+)",1))
      when(lower(col("capabilityname")).isin("foundation"),col("transactionrefno")))
    //  logger.info(" renaming unreconciled columns before"+dfJoinDigSapWare.filter(col("transactionrefno").isin("514511188","514611187")).show(false))

    dfJoinDigWare=dfJoinDigWare.withColumn("orderid",when(trim(col("orderid")).isNull.or(trim(col("orderid")).isin("")),col("transactionrefno")).otherwise(col("orderid")))

    dfFinal=dfJoinDigWare.select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status","wh_recon_status","recon_status","payload","warehouse_payload","orderid")
    dfFinal=dfFinal.dropDuplicates()

   // var checkDf=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactions"), target_env_enabled, TransidConfig," select * from "+TransidConfig.getString("oracle_target.wdcOutboundTransactions")+" fetch first 1 rows only")

    //checking the current data in unreconciled and reconciled history
    // based on capabilityname and (transactionrefno or OrderId or Prevtransactionrefno) combination and deriving the final fields
    var dfFinalUnrecon: org.apache.spark.sql.DataFrame = null
    var dfFinalUnreconRight: org.apache.spark.sql.DataFrame = null
    var dfFinalRight: org.apache.spark.sql.DataFrame = null
    var dfFinalResult: org.apache.spark.sql.DataFrame = null
    // Checking whether unreconciled and reconciled history exists in mentioned path or not and then perform the logic inside clause
      val outboundExtractOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactions"), target_env_enabled, TransidConfig)
      val outboundExtractArchieveOracle=CommonMethods.extractJDBC(spark, TransidConfig.getString("oracle_target.wdcOutboundTransactionsArchive"), target_env_enabled, TransidConfig)
      var UnReconDF =  outboundExtractOracle.filter(col("recon_status").isin("N")).union(outboundExtractArchieveOracle.filter(col("recon_status").isin("N")))
      //unreconcile data right join to get previous unreconcile data
      dfFinalRight=dfFinal.withColumnRenamed("transactionrefno","dfright_transactionrefno").withColumnRenamed("apiname","dfright_apiname")
        .select("dfright_transactionrefno","dfright_apiname")
      dfFinalUnreconRight=dfFinalRight.join(UnReconDF,dfFinalRight.col("dfright_apiname").equalTo(UnReconDF.col("apiname"))
        .and(dfFinalRight.col("dfright_transactionrefno").equalTo(UnReconDF.col("transactionrefno"))),"right_outer")
      dfFinalUnreconRight=dfFinalUnreconRight.filter(col("dfright_apiname").isNull.and(col("dfright_transactionrefno").isNull))
        .select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status",
          "wh_recon_status","recon_status","payload","warehouse_payload","orderid")
      //unreconcile data left join to get current unreconcile data
      UnReconDF=UnReconDF.select(col("capabilityname").as("unrecon_capabilityname"),col("apiname").as("unrecon_apiname"),col("transactionrefno").as("unrecon_transactionrefno"),
        col("digital_recon_date").as("unrecon_digital_recon_date"),col("warehouse_recon_date").as("unrecon_warehouse_recon_date"),col("digital_recon_status").as("unrecon_digital_recon_status"),
        col("wh_recon_status").as("unrecon_wh_recon_status"),col("recon_status").as("unrecon_recon_status"),col("payload").as("unrecon_payload"),col("warehouse_payload").as("unrecon_warehouse_payload"),col("orderid").as("unrecon_orderid"))
      //left joining the current data with unreconciled data to get history of same transcaionrefno and deriving required files
      logger.info("left joining the current data with unreconciled data to get history of same transcaionrefno and deriving required files")
      dfFinalUnrecon=dfFinal.join(UnReconDF,dfFinal.col("apiname").equalTo(UnReconDF.col("unrecon_apiname"))
        .and(dfFinal.col("transactionrefno").equalTo(UnReconDF.col("unrecon_transactionrefno"))),"left_outer")
      dfFinalUnrecon=dfFinalUnrecon
        .withColumn("prevtransactionrefno",col("transactionrefno"))
        .withColumn("capabilityname",when(col("capabilityname").isNotNull,col("capabilityname")).otherwise(col("unrecon_capabilityname")))
        .withColumn("apiname",when(col("apiname").isNotNull,col("apiname")).otherwise(col("unrecon_apiname")))
        .withColumn("digital_recon_date",when(col("digital_recon_date").isNotNull,col("digital_recon_date")).otherwise(col("unrecon_digital_recon_date")))
        .withColumn("warehouse_recon_date",when(col("warehouse_recon_date").isNotNull,col("warehouse_recon_date")).otherwise(col("unrecon_warehouse_recon_date")))
        .withColumn("digital_recon_status",when(col("digital_recon_status").isin("Y").or(col("unrecon_digital_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
        .withColumn("wh_recon_status",when(col("wh_recon_status").isin("Y").or(col("unrecon_wh_recon_status").isin("Y")),lit("Y")).otherwise(lit("N")))
        .withColumn("payload",when(col("payload").isNotNull,col("payload")).otherwise(col("unrecon_payload")))
        .withColumn("orderid",when(not(col("orderid").equalTo(col("transactionrefno"))).and(trim(col("orderid")).isNotNull),col("orderid")).otherwise(col("unrecon_orderid")))
        .withColumn("warehouse_payload",when(col("warehouse_payload").isNotNull,col("warehouse_payload")).otherwise(col("unrecon_warehouse_payload")))
      dfFinalUnrecon=dfFinalUnrecon.withColumn("recon_status",when(col("digital_recon_status").isin("Y").and(col("wh_recon_status").isin("Y"))
        ,lit("Y")).otherwise(lit("N")))
      dfFinalResult=dfFinalUnrecon.select("capabilityname","apiname","transactionrefno","digital_recon_date","warehouse_recon_date","digital_recon_status",
        "wh_recon_status","recon_status","payload","warehouse_payload","prevtransactionrefno","orderid")

      // Checking whether reconciled history exists in mentioned path or not and then perform the logic inside clause
      //Reading reconciled data from csv files
      // ReconDFOrg = CommonMethods.readFromCSVFile(TransidConfig.getString("extract_dir.OutboundReconcileExtract"), "|", spark, SchemaDefinitionWdc.outboundUnreconcile)
      ReconDFOrg =  outboundExtractOracle.filter(col("recon_status").isin("Y")).union(outboundExtractArchieveOracle.filter(col("recon_status").isin("Y")))
      ReconDFOrg = ReconDFOrg.select(col("capabilityname").as("recon_capabilityname"),col("apiname").as("recon_apiname"),col("transactionrefno").as("recon_transactionrefno"),col("digital_recon_date").as("recon_digital_recon_date"),
        col("warehouse_recon_date").as("recon_warehouse_recon_date"),col("digital_recon_status").as("recon_digital_recon_status"),col("wh_recon_status").as("recon_wh_recon_status"),
        col("recon_status").as("recon_recon_status"),col("payload").as("recon_payload"), col("warehouse_payload").as("recon_warehouse_payload"),col("orderid").as("recon_orderid"))
      //Joining current data with reconciled data
      logger.info("Joining current data with reconciled data ")
      dfFinalResult = dfFinalResult.join(ReconDFOrg, ReconDFOrg.col("recon_transactionrefno").equalTo(dfFinalResult.col("transactionrefno"))
        .and(ReconDFOrg.col("recon_apiname").equalTo(dfFinalResult.col("apiname"))), "left_outer")
      dfFinalResult=dfFinalResult.filter(col("recon_capabilityname").isNull.and(col("recon_transactionrefno").isNull))
      dfFinalResult=dfFinalResult.withColumn("digital_recon_date",to_date(col("digital_recon_date"),"yyyy-MM-dd"))
        .withColumn("warehouse_recon_date",to_date(col("warehouse_recon_date"),"yyyy-MM-dd"))
      val windowSpecIntial = Window.partitionBy("capabilityname","transactionrefno").orderBy(desc("recon_status"),desc("digital_recon_status"),desc("wh_recon_status"),desc("digital_recon_date"),desc("warehouse_recon_date"))
      dfFinalResult=dfFinalResult.withColumn("rowNumber",row_number().over(windowSpecIntial))
      dfFinalResult=dfFinalResult.filter(col("rowNumber").equalTo(1)).dropDuplicates("transactionrefno","capabilityname")
      dfFinalResult=dfFinalResult.filter(col("transactionrefno").isNotNull.and(col("capabilityname").isNotNull))
      dfFinalResult = dfFinalResult.select("capabilityname", "apiname", "transactionrefno", "digital_recon_date", "warehouse_recon_date", "digital_recon_status",
        "wh_recon_status", "recon_status", "payload", "warehouse_payload","prevtransactionrefno","orderid")
      logger.info("Joining current data with reconciled data "+dfFinalResult.printSchema())
      dfFinalResult = dfFinalResult.withColumn("recon_create_date",least(col("digital_recon_date"),col("warehouse_recon_date")))
      val dbtable=TransidConfig.getString("oracle_target.wdcOutboundTransactions")
      val temptable=TransidConfig.getString("oracle_target.wdcOutboundTransactionsTemp")
      val upsertQuery= s""" MERGE INTO $dbtable target USING $temptable source
          on (target.transactionrefno=source.transactionrefno
          and target.capabilityname=source.capabilityname)
          WHEN MATCHED THEN UPDATE SET
					target.APINAME=source.APINAME ,
					target.DIGITAL_RECON_DATE=source.DIGITAL_RECON_DATE ,
					target.WAREHOUSE_RECON_DATE=source.WAREHOUSE_RECON_DATE ,
					target.DIGITAL_RECON_STATUS=source.DIGITAL_RECON_STATUS ,
					target.WH_RECON_STATUS=source.WH_RECON_STATUS ,
					target.RECON_STATUS=source.RECON_STATUS ,
					target.PAYLOAD=source.PAYLOAD ,
					target.WAREHOUSE_PAYLOAD=source.WAREHOUSE_PAYLOAD ,
          target.PREVTRANSACTIONREFNO=source.PREVTRANSACTIONREFNO ,
					target.ORDERID=source.ORDERID
					WHEN NOT MATCHED THEN INSERT (CAPABILITYNAME,APINAME,TRANSACTIONREFNO,DIGITAL_RECON_DATE,WAREHOUSE_RECON_DATE,DIGITAL_RECON_STATUS,WH_RECON_STATUS,RECON_STATUS,PAYLOAD,WAREHOUSE_PAYLOAD,PREVTRANSACTIONREFNO,ORDERID,RECON_CREATE_DATE)
					VALUES (source.CAPABILITYNAME,source.APINAME,source.TRANSACTIONREFNO,source.DIGITAL_RECON_DATE,source.WAREHOUSE_RECON_DATE,source.DIGITAL_RECON_STATUS,source.WH_RECON_STATUS,source.RECON_STATUS,source.PAYLOAD,source.WAREHOUSE_PAYLOAD,source.PREVTRANSACTIONREFNO,source.ORDERID,source.RECON_CREATE_DATE)"""
      CommonMethods.saveToJDBC(dfFinalResult, TransidConfig.getString("oracle_target.wdcOutboundTransactionsTemp"), "overwrite", target_env_enabled, TransidConfig)
      CommonMethods.saveJDBC(target_env_enabled, TransidConfig, upsertQuery)


    logger.info(" Updating next cycle timestamp in time conf")
    //Time conf file update
    // reading previous soa_startTime and adding 1 hour and updating time conf file for next cycle
   /* val rowValues = soa_startTime.split(",").map(_.trim)
    val row =Row.fromSeq(rowValues)
    val rows: RDD[Row] =spark.sparkContext.parallelize(Seq(row))
    val schema = StructType(StructField("startTimestamp", StringType, false) :: Nil)
    dftime = spark.createDataFrame(rows,schema)
    dftime = dftime.withColumn("startTimestamp", to_timestamp(col("startTimestamp"),"yyyy-MM-dd HH:mm:ss"))
    dftime = dftime.withColumn("startTime", expr("startTimestamp + INTERVAL 15 MINUTES"))
    val nextcycletime = dftime.select("startTime").first().getTimestamp(0)
    logger.info(" next cycle timestamp is " + nextcycletime)
    val output = fileSystem.create(new Path(TransIdConstants.getString("OUT_TIME_CONF")), true)
    val writer = new PrintWriter(output)
    val processed_endtime = timeFormat.format(cal.getTime).toString()
    writer.write("startTime=" + "\"" + nextcycletime + "\"" + "\n")
    writer.write("runTime=" + "\"" + processed_endtime + "\"")
    writer.close() */

    val end_time = System.nanoTime
    logger.info("WDC Outbound transaction - extraction completed on " + end_time)
    logger.info("WDC Outbound transaction - extraction total time taken " + ((end_time - start_time) / 1e9d) + " seconds")
    logger.info("<----------- WDC Outbound transaction extraction has completed ---------------->")

    spark.close()
    spark.stop()
  }

}