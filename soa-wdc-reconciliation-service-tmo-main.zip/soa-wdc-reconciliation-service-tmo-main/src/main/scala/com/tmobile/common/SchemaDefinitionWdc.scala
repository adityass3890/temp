package com.tmobile.common

import org.apache.spark.sql.types._

object SchemaDefinitionWdc extends Enumeration {
  //Inbound Schema
  val inboundUnreconcile = StructType(StructField("location", StringType, true) ::
    StructField("transactionrefno", StringType, true) ::
    StructField("transconfirmnumber", StringType, true) ::
    StructField("capabilityname", StringType, true) ::
    StructField("apiname", StringType, true) ::
    StructField("digital_recon_date", StringType, true) ::
    StructField("warehouse_create_date", StringType, true) ::
    StructField("sor_recon_date", StringType, true) ::
    StructField("digital_recon_status", StringType, true) ::
    StructField("wh_recon_status", StringType, true) ::
    StructField("sor_recon_status", StringType, true) ::
    StructField("recon_status", StringType, true) ::
    StructField("payload", StringType, true) ::
    StructField("sap_status_payload", StringType, true) ::
    StructField("prevtransactionrefno", StringType, true) ::
    StructField("orderid", StringType, true) :: Nil)

  //Outbound Schema
  val outboundUnreconcile = StructType(StructField("capabilityname", StringType, true) ::
    StructField("apiname", StringType, true) ::
    StructField("transactionrefno", StringType, true) ::
    StructField("digital_recon_date", StringType, true) ::
    StructField("warehouse_recon_date", StringType, true) ::
    StructField("digital_recon_status", StringType, true) ::
    StructField("wh_recon_status", StringType, true) ::
    StructField("recon_status", StringType, true) ::
    StructField("payload", StringType, true) ::
    StructField("warehouse_payload", StringType, true) ::
    StructField("orderid", StringType, true) :: Nil)

  val pierTicketProcessing = StructType(StructField("TRANSREFNO", StringType, true) ::
    StructField("TRANSCONFNO", StringType, true) ::
    StructField("CAPABILITYNAME", StringType, true) ::
    StructField("PIER_TICKETNUMBER", StringType, true) ::
    StructField("PIER_TICKETOPENDATE", StringType, true) ::
    StructField("PIER_TICKETSTATUS", StringType, true) ::
    StructField("PIER_TICKETCLOSEDATE", StringType, true) ::
    StructField("COMMENTS", StringType, true) ::
    StructField("RECON_FLAG", StringType, true) :: Nil)

  val inboundUnreconcileCsv = StructType(StructField("location", StringType, true) ::
    StructField("transactionrefno", StringType, true) ::
    StructField("transconfirmnumber", StringType, true) ::
    StructField("capabilityname", StringType, true) ::
    StructField("apiname", StringType, true) ::
    StructField("digital_recon_date", StringType, true) ::
    StructField("warehouse_create_date", StringType, true) ::
    StructField("sor_recon_date", StringType, true) ::
    StructField("digital_recon_status", StringType, true) ::
    StructField("wh_recon_status", StringType, true) ::
    StructField("sor_recon_status", StringType, true) ::
    StructField("recon_status", StringType, true) ::
    StructField("payload", StringType, true) ::
    StructField("sap_status_payload", StringType, true) ::
    StructField("prevtransactionrefno", StringType, true) :: Nil)

  val outboundUnreconcileCsv = StructType(StructField("capabilityname", StringType, true) ::
    StructField("apiname", StringType, true) ::
    StructField("transactionrefno", StringType, true) ::
    StructField("digital_recon_date", StringType, true) ::
    StructField("warehouse_recon_date", StringType, true) ::
    StructField("digital_recon_status", StringType, true) ::
    StructField("wh_recon_status", StringType, true) ::
    StructField("recon_status", StringType, true) ::
    StructField("payload", StringType, true) ::
    StructField("warehouse_payload", StringType, true) :: Nil)
}